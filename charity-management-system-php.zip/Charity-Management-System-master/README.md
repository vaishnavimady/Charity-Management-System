# Charity-Management-System

This system has three modules namely, Donor, Help Needy, Volunteer. Donor can register on the website .After registration donor has to do login. After login donor can make the payment very easily. Payment process can be done by debit cards. After the successful payment completion donor receive receipt for the payment. Also, for the sake of donor’s donation acknowledgement, donor can print the receipt. If someone who want to do volunteering, can register themselves as a volunteer just by answering some simple questions.Also help needy or NGO can register themselves and after the login they have to answer the simple questions. They can view the previous events list. Donor can simply register and login using credentials.

Technologies used :
#Front End- HTML, CSS
#Backend- PHP
#Database- PostgreSQL
